export class CreatePostDto {
  readonly title: string;
  readonly body: string;
  readonly userId: number;
}